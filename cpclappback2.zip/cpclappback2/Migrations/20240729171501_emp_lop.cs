﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace cpclapp.Migrations
{
    /// <inheritdoc />
    public partial class emp_lop : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
